package com.shangan.trade.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradeUserApplicationTests {

    @Test
    void contextLoads() {
    }

}
