package com.shangan.coupon.coupon.release;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouponReleaseApplicationTests {

    @Test
    void contextLoads() {
    }

}
