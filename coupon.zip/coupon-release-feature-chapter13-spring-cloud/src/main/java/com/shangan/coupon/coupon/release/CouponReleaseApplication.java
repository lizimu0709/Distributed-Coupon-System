package com.shangan.coupon.coupon.release;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CouponReleaseApplication {

    public static void main(String[] args) {
        SpringApplication.run(CouponReleaseApplication.class, args);
    }

}
