package com.shangan.trade.coupon.db.model;

import lombok.Data;

@Data
public class SendCouponTaskModel {

    private long batchId;

    private long userId;

}
