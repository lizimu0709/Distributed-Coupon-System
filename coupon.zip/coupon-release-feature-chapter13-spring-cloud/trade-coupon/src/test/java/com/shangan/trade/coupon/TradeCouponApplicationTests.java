package com.shangan.trade.coupon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradeCouponApplicationTests {

    @Test
    void contextLoads() {
    }

}
